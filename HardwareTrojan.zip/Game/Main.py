from Trojan import *
import numpy as np


Num_Trojans = 4
K = 2
Num_Stages = 1000
Value = np.array([1,3,7,12])
F = 8

S0iterations = 50
counter = 0
SA = CreateSA(Num_Trojans)
PA = Probability(SA)
SD = CreateSD(SA, Num_Trojans, K)
PD = Probability(SD)
PA, PD, tempPA, tempPD, tempPA1,tempPD1,tempPA2,tempPD2 = StartStage(PA, PD, SA, SD, S0iterations)

Game1(Num_Trojans, K, Num_Stages,Value,F,tempPA,tempPD,SA,SD)
Game2(Num_Trojans, K, Num_Stages,Value,F,tempPA1,tempPD1,SA,SD)
Game3(Num_Trojans, K, Num_Stages,Value,F,tempPA2,tempPD2,SA,SD)


#print(PA,PD)

#print(NEA, NED)








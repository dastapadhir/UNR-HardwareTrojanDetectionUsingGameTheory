import numpy as np
from functools import reduce
import operator as op
from itertools import combinations
import matplotlib.pyplot as plt


def SizeofSpace(Num_Trojans, K):
    K = min(K, Num_Trojans - K)
    numer = reduce(op.mul, range(Num_Trojans, Num_Trojans - K, -1), 1)
    denom = reduce(op.mul, range(1, K + 1), 1)
    return numer / denom

def CreateSA(Num_Trojans):
    a = []
    for x in range(1,Num_Trojans+1):
        a.append(x)
    a = np.array(a)
    return a

def CreateSD(SA,Num_Trojans, K):
    Size = SizeofSpace(Num_Trojans, K)
    test = int(Size)
    comb = combinations(SA,K)
    val = np.array(list(comb))
    li2 = [y for x in val for y in x]
    ','.join(map(str,li2))
    num = []
    for x in range(0,test):
        num.append(x)
    for x in range(0,len(li2),2):
        num[int(x/2)] = int(str(li2[x]) + str(li2[x+1]))

    return np.asarray(num)

def Probability(array):
    a = []
    for x in range(0,array.shape[0]):
        a.append(x)
    a = np.array(a,dtype = np.float)
    for i in range(0,a.shape[0]):
        a[i] = 1.0/float(a.shape[0])
    return a

def Prob_Yes(Results):
    count = 0.0
    for x in range(0,Results.shape[0]):
        if Results[x] == 'Yes':
            count = count + 1
    return count/Results.shape[0]

def Prob_Strategy(value, AttackerPlay,mode):
    count = 0.0
    for x in range(0, AttackerPlay.shape[0]):
        if AttackerPlay[x] == value:
            count = count + 1
    return count / AttackerPlay.shape[0]

def Prob_StrategyGivenYes(value, Results, AttackerPlay,mode):
    val_count = 0.0
    yes_count = 0.0
    for x in range(0, Results.shape[0]):
        if Results[x] == 'Yes':
            yes_count = yes_count + 1
            if AttackerPlay[x] == value:
                val_count = val_count +1
    if yes_count == 0:
        return 0
    return val_count/yes_count

def BayesianLearning(SA,AttackerPlay,Results,iterations,mode):
    Conditionals = []
    for x in range(0,SA.shape[0]):
        Conditionals.append(x)
        val = Prob_Strategy(SA[x], AttackerPlay,mode)
        if val == 0:
            Conditionals[x] = 0
        else:
            Conditionals[x] = Prob_StrategyGivenYes(SA[x], Results, AttackerPlay,mode) * Prob_Yes(Results) / val
    Conditionals = np.array(Conditionals, dtype=np.float)
    return Conditionals

def Normalize(Array):
    sum = 0.0
    for x in range(0,Array.shape[0]):
        sum = sum + Array[x]
    if sum == 0.0:
        return [5123]
    else:
        for x in range(0,Array.shape[0]):
            Array[x] = Array[x]/sum
        return Array

def ProbAttacker(A,PA):
    mid = 1.0/A.shape[0]
    for x in range(0,A.shape[0]):
        diff = mid - A[x]
        diff = diff/2.0
        A[x] = PA[x] + diff
    return A

def ProbDefender(A,PA):
    mid = 1.0/A.shape[0]
    for x in range(0,A.shape[0]):
        diff = A[x] - mid
        if diff >= 0:
            diff = diff/8.0
            A[x]  = PA[x] + diff
        else:
            diff = diff/8.0
            A[x] = PA[x] - diff
    return A

def StartStage(PA,PD,SA,SD,iterations):
    AttackerPlay = []
    DefenderPlay = []
    Results = []
    for x in range(0,iterations):
        AttackerPlay.append(x)
        val = np.random.choice(SA.shape[0], 1, replace=False)
        AttackerPlay[x] = SA[val]
    for x in range(0, iterations):
        DefenderPlay.append(x)
        val = np.random.choice(SD.shape[0], 1, replace=False)
        DefenderPlay[x] = SD[val]
    for x in range(0,iterations):
        Results.append(x)
        num,rem = divmod(DefenderPlay[x],10)
        if AttackerPlay[x] == num or AttackerPlay[x] == rem:
            Results[x] = 'Yes'
        else:
            Results[x] = 'No'
    AttackerPlay = np.array(AttackerPlay)
    DefenderPlay = np.array(DefenderPlay)
    Results = np.array(Results)

    #for x in range(0,iterations):
        #print(AttackerPlay[x], DefenderPlay[x], Results[x])
    NewProbA = BayesianLearning(SA, AttackerPlay, Results, iterations,0)
    temp = NewProbA
    NewProbD = BayesianLearning(SD, DefenderPlay, Results,iterations,1)
    temp2 = NewProbD
    NewProbA = Normalize(NewProbA)
    if(NewProbA[0] == 5123):
        NewProbA = temp
    if(NewProbD[0] == 5123):
        NewProbD = temp2
    Normalize(NewProbD)
    NewProbA = ProbAttacker(NewProbA,PA)
    NewProbD = ProbDefender(NewProbD,PD)
    return NewProbA,NewProbD,NewProbA,NewProbD,NewProbA,NewProbD,NewProbA,NewProbD

def MatrixCreation(SA,SD,Value,F):
    table = np.ndarray(shape=(SA.shape[0],SD.shape[0]),dtype = int)
    for i in range(0,SA.shape[0]):
        for j in range(0,SD.shape[0]):
            num, rem = divmod(SD[j], 10)
            if SA[i] == num or SA[i] == rem:
                table[i][j] = -F
            else:
                table[i][j] = Value[i]
    return table

def StagePayoff(SA,SD, PA,PD, matrix):
    AP = np.argmax(PA)
    DP = np.argmax(PD)
    return matrix[AP][DP],AP,DP

def UpdateAttackerProb(SA,PA,DP,matrix,payoff,Value,F):
    if payoff == -F:
        count = 0.0
        num = []
        for i in range(0,matrix.shape[0]):
            if matrix[i][DP] != -F:
                num.append(matrix[i][DP])
        num = np.array(num)
        for x in range(0,num.shape[0]):
            for y in range(0,Value.shape[0]):
                if num[x] == Value[y]:
                    PA[y] = PA[y] + 0.01*(x+1)
                    count = count + PA[y]
        remaining = 1.0 - count
        number = SA.shape[0] - num.shape[0]
        val = remaining/number
        for x in range(0,num.shape[0]):
            for y in range(0,Value.shape[0]):
                if num[x] != Value[y]:
                    PA[y] = PA[y] - 0.01*val
                    count = count + PA[y]
    else:
        for i in range(0, matrix.shape[0]):
            if matrix[i][DP] != -F:
                PA[i] = PA[i] + 0.01
            else:
                PA[i] = PA[i] - 0.01
    return PA

def UpdateDefenderProb(PD,AP,matrix,payoff):
    if payoff < 0:
        for i in range(0,matrix.shape[1]):
            if matrix[AP][i] == payoff:
                PD[i] = PD[i] + 0.01
            else:
                PD[i] = PD[i] - 0.01
    else:
        for i in range(0, matrix.shape[1]):
            if matrix[AP][i] == payoff:
                PD[i] = PD[i] - 0.01
            else:
                PD[i] = PD[i] + 0.01
    return PD

def MainStage(PA,PD, SA,SD,Value,F,choice,delay,counter,Ax,Dx):
    matrix = MatrixCreation(SA,SD,Value,F)
    payoff,AP,DP = StagePayoff(SA,SD,PA,PD,matrix)
    if choice == 1:
        if payoff == -F:
            #print(SA[AP], SD[DP],1)
            #print(1)
            #print(AP , "," , DP)
            Ax.append(AP+1)
            PA = UpdateAttackerProb(SA,PA,DP,matrix,payoff,Value,F)
            Dx.append(DP+1)
            PD = UpdateDefenderProb(PD,AP,matrix,payoff)
        else:
            #print(SA[AP], SD[DP],0)
            #print(0)
            #print(AP, ", ", DP)
            Ax.append(AP+1)
            PA = UpdateAttackerProb(SA, PA, DP, matrix, payoff, Value,F)
            Dx.append(DP+1)
            PD = UpdateDefenderProb(PD,AP,matrix,payoff)
        return PA,PD
    elif choice == 2:
        if payoff == -F:
            #print(SA[AP], SD[DP],1)
            #print(1)
            #print(AP , "," , DP)
            Ax.append(AP+1)
            PA = UpdateAttackerProb(SA,PA,DP,matrix,payoff,Value,F)
            if counter == delay:
                Dx.append(DP + 1)
                PD = UpdateDefenderProb(PD,AP,matrix,payoff)
            else:
                Dx.append(DP+1)
        else:
            #print(SA[AP], SD[DP],0)
            #print(0)
            #print(AP, ", ", DP)
            Ax.append(AP+1)
            PA = UpdateAttackerProb(SA, PA, DP, matrix, payoff, Value,F)
            if counter == delay:
                Dx.append(DP + 1)
                PD = UpdateDefenderProb(PD,AP,matrix,payoff)
            else:
                Dx.append(DP+1)
        return PA,PD
    elif choice == 3:
        if payoff == -F:
            #print(SA[AP], SD[DP],1)
            #print(1)
           # print(AP , "," , DP)
            if counter == delay:
                Ax.append(AP + 1)
                PA = UpdateAttackerProb(SA,PA,DP,matrix,payoff,Value,F)
            else:
                Ax.append(AP+1)
            Dx.append(DP + 1)
            PD = UpdateDefenderProb(PD,AP,matrix,payoff)
        else:
            #print(SA[AP], SD[DP],0)
            #print(0)
            #print(AP, ", ", DP)
            if counter == delay:
                Ax.append(AP + 1)
                PA = UpdateAttackerProb(SA, PA, DP, matrix, payoff, Value, F)
            else:
                Ax.append(AP+1)
            Dx.append(DP + 1)
            PD = UpdateDefenderProb(PD,AP,matrix,payoff)
        return PA,PD

def Game1(Num_Trojans, K,Num_Stages,Value,F,PA,PD,SA,SD):
    Ax = []
    Dx = []
    y = []

    delay = 7
    gamecounter = 1

    # print("Press 1. Attacker and Defender update together")
    # print("Press 2. Delay Defender Update")
    # print("Press 3. Delay Attacker Update")
    # choice = int(input())

    choice = 1

    counter = 0
    gamecounter = 1

    # if choice == 2 or choice == 3:
    #     print("How many of stages of delay??")
    #     delay = int(input())



    while counter != Num_Stages:
        if choice == 1:
            PA,PD = MainStage(PA, PD, SA, SD, Value, F,choice,delay,gamecounter,Ax,Dx)
        PA = Normalize(PA)
        PD = Normalize(PD)
        counter = counter + 1

        if choice == 2 or choice == 3:
            if gamecounter == delay:
                gamecounter = 1
            else:
                gamecounter = gamecounter + 1

        if choice == 1:
            y.append(counter)

    print(counter)
    if choice == 1:
        for i in range(2):
            if i == 0:
                plt.figure(i+1)
                plt.plot(y, Ax)
                plt.yticks(np.arange(min(Ax), max(Ax) +1, 1.0))
                plt.xlabel("Game Stage")
                plt.ylabel("Optimal Strategy for Attacker")
                plt.savefig('/home/tapadhird/Desktop/SAttacker.png')

            else:
                plt.figure(i+1)
                plt.plot(y, Dx)
                plt.yticks(np.arange(min(Dx), max(Dx) +1, 1.0))
                plt.xlabel("Game Stage")
                plt.ylabel("Optimal Strategy for Defender")
                plt.savefig('/home/tapadhird/Desktop/SDefender.png')
        plt.show()
    return


def Game2(Num_Trojans, K,Num_Stages,Value,F,PA,PD,SA,SD):
    Ax = []
    Dx = []
    y = []

    delay = 7
    gamecounter = 1

    # print("Press 1. Attacker and Defender update together")
    # print("Press 2. Delay Defender Update")
    # print("Press 3. Delay Attacker Update")
    # choice = int(input())

    choice = 2

    counter = 0
    gamecounter = 1

    # if choice == 2 or choice == 3:
    #     print("How many of stages of delay??")
    #     delay = int(input())


    while counter != Num_Stages:
        if choice == 2:
            PA,PD = MainStage(PA, PD, SA, SD, Value, F,choice,delay,gamecounter,Ax,Dx)
        PA = Normalize(PA)
        PD = Normalize(PD)
        counter = counter + 1

        if choice == 2 or choice == 3:
            if gamecounter == delay:
                gamecounter = 1
            else:
                gamecounter = gamecounter + 1

        if choice == 2:
            y.append(counter)

    print(counter)
    if choice == 2:
        for i in range(2):
            if i == 0:
                plt.figure(i+1)
                plt.plot(y, Ax)
                plt.yticks(np.arange(min(Ax), max(Ax) +1, 1.0))
                plt.xlabel("Game Stage")
                plt.ylabel("Optimal Strategy for Attacker")
                plt.savefig('/home/tapadhird/Desktop/DDAttacker.png')

            else:
                plt.figure(i+1)
                plt.plot(y, Dx)
                plt.yticks(np.arange(min(Dx), max(Dx) +1, 1.0))
                plt.xlabel("Game Stage")
                plt.ylabel("Optimal Strategy for Defender")
                plt.savefig('/home/tapadhird/Desktop/DDDefender.png')
        plt.show()
    return

def Game3(Num_Trojans, K,Num_Stages,Value,F,PA,PD,SA,SD):
    Ax = []
    Dx = []
    y = []

    delay = 7
    gamecounter = 1

    # print("Press 1. Attacker and Defender update together")
    # print("Press 2. Delay Defender Update")
    # print("Press 3. Delay Attacker Update")
    # choice = int(input())

    choice = 3

    counter = 0
    gamecounter = 1

    # if choice == 2 or choice == 3:
    #     print("How many of stages of delay??")
    #     delay = int(input())


    while counter != Num_Stages:
        if choice == 3:
            PA,PD = MainStage(PA, PD, SA, SD, Value, F,choice,delay,gamecounter,Ax,Dx)
        PA = Normalize(PA)
        PD = Normalize(PD)
        counter = counter + 1

        if choice == 2 or choice == 3:
            if gamecounter == delay:
                gamecounter = 1
            else:
                gamecounter = gamecounter + 1

        if choice == 3:
            y.append(counter)

    print(counter)
    if choice == 3:
        for i in range(2):
            if i == 0:
                plt.figure(i+1)
                plt.plot(y, Ax)
                plt.yticks(np.arange(min(Ax), max(Ax) +1, 1.0))
                plt.xlabel("Game Stage")
                plt.ylabel("Optimal Strategy for Attacker")
                plt.savefig('/home/tapadhird/Desktop/DAAttacker.png')

            else:
                plt.figure(i+1)
                plt.plot(y, Dx)
                plt.yticks(np.arange(min(Dx), max(Dx) +1, 1.0))
                plt.xlabel("Game Stage")
                plt.ylabel("Optimal Strategy for Defender")
                plt.savefig('/home/tapadhird/Desktop/DADefender.png')
        plt.show()
    return